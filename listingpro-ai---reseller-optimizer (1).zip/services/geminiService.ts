
import { GoogleGenAI } from "@google/genai";
import { Platform, OptimizedListing } from "../types";

const SYSTEM_INSTRUCTION = `You are ListingPro AI, the ultimate reseller assistant.
Your task: Analyze provided media (images/videos) and text to generate professional, high-SEO marketplace listings.

RULES:
1. FORMAT: Always return a valid JSON object.
2. CONTENT: Create a catchy title, a detailed but concise description, relevant hashtags, and a suggested market price.
3. GROUNDING: Use Google Search to find current market prices and comparable listings.
4. TONE: Professional, persuasive, and optimized for the specific platform (eBay, Etsy, Poshmark, etc.).

JSON Schema:
{
  "title": "string",
  "description": "string",
  "hashtags": ["string"],
  "suggestedPrice": "string",
  "agentInsights": {
    "research": "string",
    "marketAnalysis": "string"
  }
}`;

export async function optimizeListing(
  platform: Platform,
  roughTitle: string,
  zipCode?: string,
  mediaData?: { data: string; mimeType: string }
): Promise<OptimizedListing> {
  const apiKey = process.env.API_KEY;
  
  if (!apiKey || apiKey === "undefined") {
    throw new Error("API_KEY_MISSING");
  }

  const ai = new GoogleGenAI({ apiKey });
  const model = 'gemini-3-flash-preview'; 

  const prompt = `Platform: ${platform}
Rough Description: ${roughTitle}
Location/Zip: ${zipCode || "Not provided"}
Media Attached: ${mediaData ? "Yes (" + mediaData.mimeType + ")" : "No"}

Please analyze the item and generate an optimized listing. Use search grounding for price accuracy.`;

  const parts: any[] = [{ text: prompt }];
  
  if (mediaData) {
    // Basic media validation
    const base64Data = mediaData.data.includes(',') ? mediaData.data.split(',')[1] : mediaData.data;
    parts.push({
      inlineData: {
        mimeType: mediaData.mimeType,
        data: base64Data
      }
    });
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text || "{}");
    
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.filter((chunk: any) => chunk.web)
      ?.map((chunk: any) => ({
        title: chunk.web.title || 'Market Source',
        uri: chunk.web.uri
      })) || [];

    return {
      title: result.title || roughTitle,
      description: result.description || "Optimization complete. No description generated.",
      hashtags: result.hashtags || [],
      keywords: [],
      suggestedPrice: result.suggestedPrice || "Calculating...",
      agentInsights: result.agentInsights || { research: "Market scan complete.", marketAnalysis: "Review sources for details." },
      sources
    } as OptimizedListing;
  } catch (err) {
    console.error("Gemini Execution Error:", err);
    throw err;
  }
}
