
import React, { useState, useRef, useEffect } from 'react';
import { Platform, OptimizedListing } from './types';
import { optimizeListing } from './services/geminiService';
import { Button } from './components/Button';
import { Card } from './components/Card';

const App: React.FC = () => {
  const [platform, setPlatform] = useState<Platform>(Platform.EBAY);
  const [roughTitle, setRoughTitle] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [media, setMedia] = useState<{ data: string; mimeType: string } | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [activeAgent, setActiveAgent] = useState<number>(0);
  const [result, setResult] = useState<OptimizedListing | null>(null);
  const [errorState, setErrorState] = useState<{ type: 'congestion' | 'setup' | 'none', message: string }>({ type: 'none', message: '' });
  const [copySuccess, setCopySuccess] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let interval: any;
    if (isOptimizing) {
      setActiveAgent(1);
      interval = setInterval(() => {
        setActiveAgent((prev) => (prev < 3 ? prev + 1 : 1));
      }, 1500);
    } else {
      setActiveAgent(0);
      if (interval) clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isOptimizing]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setMedia({
          data: reader.result as string,
          mimeType: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOptimize = async () => {
    if (!roughTitle && !media) {
      setErrorState({ type: 'congestion', message: 'Please provide item details or media.' });
      return;
    }
    setIsOptimizing(true);
    setErrorState({ type: 'none', message: '' });
    setResult(null);
    try {
      const data = await optimizeListing(platform, roughTitle, zipCode, media || undefined);
      setResult(data);
    } catch (err: any) {
      if (err.message === "API_KEY_MISSING") {
        setErrorState({ 
          type: 'setup', 
          message: 'Connection Core missing. Add your API_KEY to Netlify Environment Variables to activate the system.' 
        });
      } else {
        setErrorState({ 
          type: 'congestion', 
          message: 'System congestion detected. The engine is busy or the file is too large. Please try again.' 
        });
      }
    } finally {
      setIsOptimizing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col font-['Inter'] selection:bg-blood-500/30">
      <header className="bg-black/40 backdrop-blur-md border-b border-white/5 sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blood-500 rounded flex items-center justify-center text-white font-black text-lg">L</div>
            <h1 className="text-sm font-black text-white tracking-widest uppercase">ListingPro <span className="text-blood-500">v2.10</span></h1>
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-2 bg-white/5 px-3 py-1 rounded-full border border-white/5">
              <div className={`w-1.5 h-1.5 rounded-full ${isOptimizing ? 'bg-blood-500 animate-pulse' : 'bg-green-500'}`}></div>
              <span className="text-[8px] font-bold text-gray-500 uppercase tracking-tighter">
                {isOptimizing ? 'Engine Running' : 'Ready'}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl mx-auto px-6 py-8 w-full grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Input */}
        <div className="lg:col-span-5 space-y-6">
          <Card glow>
            <div className="space-y-6">
              <div>
                <label className="text-[9px] font-black text-gray-500 uppercase tracking-widest mb-3 block">Marketplace Target</label>
                <div className="grid grid-cols-3 gap-1">
                  {[Platform.EBAY, Platform.POSHMARK, Platform.ETSY, Platform.FACEBOOK, Platform.AMAZON, Platform.TIKTOK].map((p) => (
                    <button 
                      key={p} 
                      onClick={() => setPlatform(p)}
                      className={`py-2 rounded text-[8px] font-black uppercase tracking-tight transition-all border ${platform === p ? 'bg-blood-500 border-blood-500 text-white shadow-glow' : 'bg-white/5 border-white/5 text-gray-500 hover:text-gray-300'}`}
                    >
                      {p.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <textarea
                  value={roughTitle}
                  onChange={(e) => setRoughTitle(e.target.value)}
                  placeholder="Enter item name, features, or defects..."
                  className="w-full bg-white/2 border border-white/10 rounded-xl px-4 py-4 text-sm text-white placeholder:text-gray-700 focus:border-blood-500/50 focus:bg-white/5 outline-none min-h-[140px] transition-all resize-none"
                />
                <input
                  value={zipCode}
                  onChange={(e) => setZipCode(e.target.value)}
                  placeholder="Zip Code (Optional for localized pricing)"
                  className="w-full bg-white/2 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-700 focus:border-blood-500/50 focus:bg-white/5 outline-none transition-all"
                />
              </div>

              <div 
                onClick={() => fileInputRef.current?.click()} 
                className={`border-2 border-dashed rounded-2xl p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${media ? 'border-blood-500/50 bg-blood-500/5' : 'border-white/10 hover:border-white/20 hover:bg-white/2'}`}
              >
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*,video/*" className="hidden" />
                {media ? (
                  <div className="relative w-full aspect-video overflow-hidden rounded-xl">
                    {media.mimeType.startsWith('video') ? (
                      <video src={media.data} className="w-full h-full object-cover" autoPlay loop muted />
                    ) : (
                      <img src={media.data} className="w-full h-full object-cover" />
                    )}
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <span className="text-[10px] font-black text-white uppercase tracking-widest">Replace Media</span>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-3">
                      <svg className="w-6 h-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Add Item Media (Photo/Video)</p>
                  </div>
                )}
              </div>

              {errorState.type !== 'none' && (
                <div className={`p-4 rounded-xl border ${errorState.type === 'setup' ? 'bg-blue-500/10 border-blue-500/30 text-blue-300' : 'bg-blood-500/10 border-blood-500/30 text-blood-300'} text-[10px] font-bold leading-relaxed`}>
                  <div className="flex gap-2 items-start">
                    <span className="mt-0.5">{errorState.type === 'setup' ? 'ℹ️' : '⚠️'}</span>
                    <div>
                      <p>{errorState.message}</p>
                      {errorState.type === 'setup' && (
                        <div className="mt-3 opacity-80 font-medium">
                          <p>1. Go to Netlify Dashboard</p>
                          <p>2. Site Settings > Environment Variables</p>
                          <p>3. Add Key: API_KEY</p>
                          <p>4. Deploy Site</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <Button onClick={handleOptimize} isLoading={isOptimizing} className="w-full py-4 uppercase font-black tracking-widest text-[11px]">
                {isOptimizing ? 'Optimization in Progress' : 'Generate Listing'}
              </Button>
            </div>
          </Card>

          {isOptimizing && (
            <div className="space-y-2 animate-pulse">
              {[
                { id: 1, text: 'Scanning Marketplace Data', active: activeAgent >= 1 },
                { id: 2, text: 'Building SEO Architecture', active: activeAgent >= 2 },
                { id: 3, text: 'Formatting Final Response', active: activeAgent >= 3 }
              ].map(agent => (
                <div key={agent.id} className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${agent.active ? 'bg-blood-500/10 border-blood-500/20' : 'bg-white/2 border-white/5 opacity-30'}`}>
                  <div className={`w-1 h-1 rounded-full ${agent.active ? 'bg-blood-500 shadow-glow' : 'bg-gray-600'}`}></div>
                  <span className="text-[9px] font-black text-white uppercase tracking-widest">{agent.text}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Output */}
        <div className="lg:col-span-7 space-y-6">
          {!result && !isOptimizing && (
            <div className="h-full min-h-[500px] border border-white/5 bg-white/[0.02] rounded-3xl flex flex-col items-center justify-center p-12 text-center">
              <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-6">
                <svg className="w-6 h-6 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-sm font-black text-gray-600 uppercase tracking-[0.4em]">Engine Standby</h3>
              <p className="mt-2 text-[9px] text-gray-700 uppercase font-black tracking-widest">Awaiting listing input for marketplace optimization.</p>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <Card title="Marketplace Ready Output" glow>
                <div className="space-y-8">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-[9px] font-black text-blood-500 uppercase tracking-widest">Optimized Title</span>
                      <button onClick={() => copyToClipboard(result.title)} className="text-[9px] font-black text-gray-500 hover:text-white transition-colors uppercase">
                        {copySuccess ? '✓ Copied' : 'Copy'}
                      </button>
                    </div>
                    <p className="text-xl font-black text-white leading-tight tracking-tight">{result.title}</p>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-[9px] font-black text-blood-500 uppercase tracking-widest">SEO Description</span>
                      <button onClick={() => copyToClipboard(result.description)} className="text-[9px] font-black text-gray-500 hover:text-white transition-colors uppercase">
                        Copy Description
                      </button>
                    </div>
                    <div className="text-[13px] text-gray-400 leading-relaxed whitespace-pre-wrap bg-black/40 p-5 rounded-xl border border-white/5">
                      {result.description}
                    </div>
                  </div>

                  {result.sources.length > 0 && (
                    <div className="pt-6 border-t border-white/5">
                      <span className="text-[9px] font-black text-blood-500 uppercase tracking-widest block mb-4">Research Grounding</span>
                      <div className="flex flex-wrap gap-2">
                        {result.sources.map((s, i) => (
                          <a key={i} href={s.uri} target="_blank" rel="noopener noreferrer" className="text-[9px] bg-white/5 border border-white/10 px-3 py-1.5 rounded hover:bg-white/10 hover:border-blood-500/50 transition-all text-gray-400 hover:text-white truncate max-w-[180px]">
                            {s.title}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card title="Price Guidance">
                  <div className="py-2">
                    <span className="text-4xl font-black text-white tracking-tighter">{result.suggestedPrice}</span>
                    <p className="text-[9px] text-gray-600 font-bold uppercase tracking-widest mt-2 leading-relaxed">
                      Suggested starting point based on similar active listings.
                    </p>
                  </div>
                </Card>
                <Card title="Intelligence">
                  <div className="space-y-3">
                    <p className="text-[11px] text-gray-400 italic leading-snug">"{result.agentInsights.marketAnalysis}"</p>
                    <div className="flex flex-wrap gap-1.5">
                      {result.hashtags.map(t => (
                        <span key={t} className="text-[8px] font-black text-blood-400 uppercase tracking-tighter bg-blood-500/5 px-2 py-0.5 rounded border border-blood-500/10">#{t}</span>
                      ))}
                    </div>
                  </div>
                </Card>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button variant="ghost" onClick={() => setResult(null)} className="text-[10px] uppercase font-black">Reset Console</Button>
                <Button onClick={() => copyToClipboard(`${result.title}\n\n${result.description}`)} className="px-10 py-4 text-[11px] uppercase font-black tracking-widest">
                  Copy All Data
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className="py-8 border-t border-white/5 text-center">
        <p className="text-[9px] font-black text-gray-800 uppercase tracking-[1em]">ListingPro AI Hub</p>
      </footer>
    </div>
  );
};

export default App;
